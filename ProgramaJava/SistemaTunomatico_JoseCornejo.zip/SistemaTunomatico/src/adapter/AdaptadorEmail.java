/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jose Tomas
 * Adapter
 */
public class AdaptadorEmail implements NotificadorHistorial{
    private ServicioEmail servicioEmail;
    private List<String> historial;
    
    public AdaptadorEmail(ServicioEmail servicioEmail){
        this.servicioEmail = servicioEmail;
        this.historial = new ArrayList<>();
    }
    
    public void enviar(String mensaje) {
        servicioEmail.enviarEmail(mensaje);
        historial.add(mensaje);
    }
    
    public void mostrarHistorial(){
        System.out.println("== Historial de Notificaciones enviadas por Email: ==");
        for (String msg : historial){
            System.out.println("- " + msg);
        }
    }
    
}
