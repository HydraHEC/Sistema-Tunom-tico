/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

/**
 *
 * @author Jose Tomas
 * Sistema Externo (Adapter)
 */
public class ServicioEmail {
    
    public void enviarEmail(String texto){
        System.out.println("Email enviado: " + texto);
    }
}
