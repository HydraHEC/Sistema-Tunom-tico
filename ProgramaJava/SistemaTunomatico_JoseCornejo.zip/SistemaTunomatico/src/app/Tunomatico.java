/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app;

import adapter.AdaptadorEmail;
import adapter.Notificador;
import adapter.NotificadorHistorial;
import adapter.ServicioEmail;
import bridge.Pantalla;
import bridge.PantallaLCD;
import bridge.TotemTurno;
import bridge.VisualizadorTurno;
import java.util.Scanner;
import single.TurnoManager;

/**
 *
 * @author Jose Tomas
 */
public class Tunomatico {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        TurnoManager manager = TurnoManager.getInstancia();
        Scanner scann = new Scanner(System.in);
        
        Notificador notificador = new AdaptadorEmail(new ServicioEmail());
        Pantalla pantalla = new PantallaLCD();
        TotemTurno totem = new VisualizadorTurno(pantalla);
        
        manager.setNotificador(notificador);
        manager.setVisualizador(totem);
        
        int opcion;
        
        while (true) {
            System.out.println("\n===== Sistema de Turnos (Tunomatico) =====");
            System.out.println("1. Registrar Servicio");
            System.out.println("2. Generar Turno");
            System.out.println("3. Atender Turno");
            System.out.println("4. Ver cola de Turnos");
            System.out.println("5. Ver historial de Correos");
            System.out.println("0. Salir");
            System.out.println("!Eliga una opcion:");
            
            opcion = scann.nextInt();
            scann.nextLine();
            
            if(opcion==1){
                System.out.print("!Nombre del servicio a Registrar: ");
                String servicio = scann.nextLine();
                manager.registrarServicio(servicio);
                
            }else if(opcion==2){
                System.out.print("!Servicio para Generar Turno: ");
                String servicioGen = scann.nextLine();
                manager.generarTurno(servicioGen);
                
            }else if(opcion==3){
                System.out.print("!Servicio para Atender Turno: ");
                String servicioAt = scann.nextLine();
                manager.atenderTurno(servicioAt);
                
            }else if(opcion==4){
                System.out.print("!Servicio a Consultar: ");
                String servicioCola = scann.nextLine();
                manager.mostrarCola(servicioCola);
                
            }else if(opcion==5){
                ((NotificadorHistorial)notificador).mostrarHistorial();
                
            }else if(opcion==0){
                System.out.println("!Saliendo del sistema...");
                break;
                
            }else{
                System.out.println("!!!!!Opcion Invalida. Intente denuevo");
                
            }
        }
    }
}
