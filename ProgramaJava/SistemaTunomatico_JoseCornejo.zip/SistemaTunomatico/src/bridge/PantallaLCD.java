/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridge;

/**
 *
 * @author Jose Tomas
 * Implementacion Concreta (Bridge)
 */
public class PantallaLCD implements Pantalla{

    @Override
    public void mostrar(String mensaje) {
        System.out.println("LCD: " + mensaje);
    }
    
}
