/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bridge;

/**
 *
 * @author Jose Tomas
 * Abstraccion Refinada (Bridge)
 */
public class VisualizadorTurno extends TotemTurno{
    
    public VisualizadorTurno(Pantalla pantalla){
        super(pantalla);
    }

    @Override
    public void mostrarTurno(String turno) {
        System.out.println("Turno Actual: " + turno);
    }
    
}
