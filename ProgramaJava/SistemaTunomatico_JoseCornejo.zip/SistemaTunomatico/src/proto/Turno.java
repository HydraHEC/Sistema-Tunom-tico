/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proto;

/**
 *
 * @author Jose Tomas
 * Prototype
 */
public abstract class Turno implements Cloneable{
    
    protected String tipo;
    protected String codigo;

    public String getTipo() {
        return tipo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
    public abstract void mostrarTurno();
    
    public Turno clonacion(){
        try {
            return (Turno) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
