/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proto;

import proto.Turno;

/**
 *
 * @author Jose Tomas
 * Prototype
 */
public class TurnoNormal extends Turno {
    
    public TurnoNormal(){
        this.tipo = "normal";
    }

    public void mostrarTurno() {
        System.out.println("Turno " + codigo + " - Tipo: " + tipo);
    }
}
