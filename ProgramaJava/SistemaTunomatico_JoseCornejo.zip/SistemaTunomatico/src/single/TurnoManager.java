/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package single;

import adapter.Notificador;
import bridge.TotemTurno;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import proto.Turno;
import proto.TurnoNormal;

/**
 *
 * @author Jose Tomas
 * Singleton
 */
public class TurnoManager {
    
    private static TurnoManager instancia;
    private Map<String, Queue<Turno>> colaTurno;
    private Map<String, Integer> contador;
    private Notificador notificador;
    private TotemTurno Tt;
    
    private TurnoManager(){
        colaTurno=new HashMap<>();
        contador= new HashMap<>();
    }
    
    public static TurnoManager getInstancia(){
        if(instancia == null){
            instancia = new TurnoManager();
        }
        return instancia;   
    }
    
    public void registrarServicio(String servicio){
        if(!colaTurno.containsKey(servicio)){
            colaTurno.put(servicio, new LinkedList<>());
            contador.put(servicio, 1);
            System.out.println("!Turno Registrado: "+ servicio);
        }
    }
    
    public Turno generarTurno(String servicio){
        if(!colaTurno.containsKey(servicio)){
            System.out.println("!!!!!Servicio no registrado");
            return null;
        }
        int numero = contador.get(servicio);
        contador.put(servicio, numero + 1);
        
        Turno nuevoTurno = new TurnoNormal();
        nuevoTurno.setCodigo(servicio.substring(0,1).toUpperCase() + String.format("%03d", numero));
        colaTurno.get(servicio).offer(nuevoTurno);
        
        System.out.println("!Turno Generado: "+ nuevoTurno.getCodigo());
        
        if(notificador!=null){
            notificador.enviar("Se ha generado el turno: "+ nuevoTurno.getCodigo());
        }
        
        return nuevoTurno;
    }
    
    public Turno atenderTurno(String servicio){
        if(!colaTurno.containsKey(servicio)){
            System.out.println("!!!!!Servicio no registrado");
            return null;
        }
        
        Turno turno = colaTurno.get(servicio).poll();
        if(turno==null){
            System.out.println("!!!!!No hay turnos pendientes");
        }else{
            System.out.println("!Atendiendo Turno: " + turno.getCodigo());
        }
        
        if(turno != null && Tt != null){
            Tt.mostrarTurno(turno.getCodigo());
        }
        
        return turno;
    }
    
    public void mostrarCola (String servicio){
        if(!colaTurno.containsKey(servicio)){
            System.out.println("!!!!!Servicio no registrado");
            return;
        }
        
        System.out.println("Cola de Turnos para " + servicio + ":");
        for(Turno t : colaTurno.get(servicio)){
            System.out.println("- " + t.getCodigo());
        }
    }
    
    public void setNotificador(Notificador notificador){
        this.notificador = notificador;
    }
    
    public void setVisualizador(TotemTurno Tt){
        this.Tt = Tt;
    }
}
